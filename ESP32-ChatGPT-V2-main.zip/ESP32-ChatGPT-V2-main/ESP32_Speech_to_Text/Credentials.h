// Provide all the crdentials here



// Your WiFi Credentials 
const char *ssid = "SSID";       // WiFi SSID Name
const char *password = "PASS";// WiFi Password ( Keep it blank if your WiFi router is open )


// Parameters of Google Speech to Text API
const String ApiKey = "Your_API_Key";// Google Speech to Text API key
String SpeechtoText_Language = "en-IN"; // Language 

// Parameters of OpenAI API 
const char* chatgpt_token = "Your_ChatGPT_Token"; // OpenAI API Key
String OpenAI_Model = "gpt-3.5-turbo-instruct"; // Model
String OpenAI_Temperature = "0.20"; // temperature
String OpenAI_Max_Tokens = "40"; //Max Tokens 
